#include <Wire.h>
#include <math.h>

#include "FXOS8700CQ.h"

// Public Methods //////////////////////////////////////////////////////////////

FXOS8700CQ::FXOS8700CQ(byte addr)
{
  address = addr;
  accelFSR = AFS_2g;     // Set the scale below either 2, 4 or 8
  accelODR = AODR_200HZ; // In hybrid mode, accel/mag data sample rates are half of this value
  magOSR = MOSR_5;     // Choose magnetometer oversample rate
}



// Writes a register
void FXOS8700CQ::writeReg(byte reg, byte value)
{
  Wire.beginTransmission(address);
  Wire.write(reg);
  Wire.write(value);
  Wire.endTransmission();
}



// Reads a register
byte FXOS8700CQ::readReg(byte reg)
{
  byte value;

  Wire.beginTransmission(address);
  Wire.write(reg);
  Wire.endTransmission();
  Wire.requestFrom(address, (uint8_t)1);
  value = Wire.read();
  Wire.endTransmission();

  return value;
}



void FXOS8700CQ::readRegs(byte reg, uint8_t count, byte dest[])
{
  uint8_t i = 0;

  Wire.beginTransmission(address);   // Initialize the Tx buffer
  Wire.write(reg);                 // Put slave register address in Tx buffer
  Wire.endTransmission(false);       // Send the Tx buffer, but send a restart to keep connection alive
  Wire.requestFrom(address, count);  // Read bytes from slave register address

  while (Wire.available()) {
    dest[i++] = Wire.read();   // Put read results in the Rx buffer
  }
}



// Read the accelerometer data
void FXOS8700CQ::readAccelData()
{
  uint8_t rawData[6];  // x/y/z accel register data stored here

  readRegs(FXOS8700CQ_OUT_X_MSB, 6, &rawData[0]);  // Read the six raw data registers into data array
  accelData.x = ((int16_t) rawData[0] << 8 | rawData[1]) >> 2;
  accelData.y = ((int16_t) rawData[2] << 8 | rawData[3]) >> 2;
  accelData.z = ((int16_t) rawData[4] << 8 | rawData[5]) >> 2;
}



// Read the magnometer data
void FXOS8700CQ::readMagData()
{
  uint8_t rawData[6];  // x/y/z accel register data stored here

  readRegs(FXOS8700CQ_M_OUT_X_MSB, 6, &rawData[0]);  // Read the six raw data registers into data array
  magData.x = ((int16_t) rawData[0] << 8 | rawData[1]);
  magData.y = ((int16_t) rawData[2] << 8 | rawData[3]);
  magData.z = ((int16_t) rawData[4] << 8 | rawData[5]);
}



// Get accelerometer resolution
float FXOS8700CQ::getAres(void)
{
  switch (accelFSR)
  {
    // Possible accelerometer scales (and their register bit settings) are:
    // 2 gs (00), 4 gs (01), 8 gs (10).
    case AFS_2g:
      return 2.0 / 8192.0;
      break;
    case AFS_4g:
      return 4.0 / 8192.0;
      break;
    case AFS_8g:
      return 8.0 / 8192.0;
      break;
  }

  return 0.0;
}



// Get magnometer resolution
float FXOS8700CQ::getMres(void)
{
  return 10. / 32768.;
}



// Read the temperature data
void FXOS8700CQ::readTempData()
{
  tempData = readReg(FXOS8700CQ_TEMP);
}




// _____________________________________________ Eigenener angepasster Code ______________________________________________________________________


/******************************************************************************
  Read Accel Mag Data
******************************************************************************/
void FXOS8700CQ::ReadAccelMagnData() {

  uint8_t rawData[12];  // x/y/z accel register data stored here

  int i = 0;

  Wire.beginTransmission(address);
  Wire.write(0x01);
  Wire.endTransmission(false);

  Wire.requestFrom(address, 6); //Wire.requestFrom(address, quantity)
  //read Temperature MSB
  //read Temperature LSB
  while (Wire.available())
  {
    rawData[i] = Wire.read();
    i++;
  }
  accelData.x = ((int16_t) rawData[0] << 8 | rawData[1]) >> 2;
  accelData.y = ((int16_t) rawData[2] << 8 | rawData[3]) >> 2;
  accelData.z = ((int16_t) rawData[4] << 8 | rawData[5]) >> 2;
  Wire.endTransmission(false);

  Wire.beginTransmission(address);
  Wire.write(0x33);
  Wire.endTransmission(false);

  Wire.requestFrom(address, 6); //Wire.requestFrom(address, quantity)
  while (Wire.available())
  {
    rawData[i] = Wire.read();
    i++;
  }
  magData.x = ((int16_t) rawData[6] << 8 | rawData[7]);
  magData.y = ((int16_t) rawData[8] << 8 | rawData[9]);
  magData.z = ((int16_t) rawData[10] << 8 | rawData[11]);
  Wire.endTransmission();


}



/******************************************************************************
  Standby
******************************************************************************/
// Put the FXOS8700CQ into standby mode.
// It must be in standby for modifying most registers
void FXOS8700CQ::standby()
{
  // write 0000 0000 = 0x00 to accelerometer control register 1 to place FXOS8700CQ into standby
  // [7-1] = 0000 000
  // [0]: active=0
  writeReg(FXOS8700CQ_CTRL_REG1, 0x00); //stand-by

}



/******************************************************************************
  Activate
******************************************************************************/

// Put the FXOS8700CQ into active mode.
// Needs to be in this mode to output data.
void FXOS8700CQ::active()
{

  // write 0000 1101 = 0x0D to accelerometer control register 1
  // [7-6]: aslp_rate=00
  // [5-3]: dr=001 for 200Hz data rate (when in hybrid mode), 110 =6.25Hz
  // [2]: lnoise=1 for low noise mode
  // [1]: f_read=0 for normal 16 bit reads
  // [0]: active=1 to take the part out of standby and enable sampling
  //                               76543210
  writeReg(FXOS8700CQ_CTRL_REG1, 0b00110101); // enable sampling
  //   writeReg(FXOS8700CQ_CTRL_REG1, 0x35); // enable sampling
}





/******************************************************************************
  FXO Initialize
******************************************************************************/
void FXOS8700CQ::init()
{

//Initialisierung nach https://community.nxp.com/docs/DOC-101073
  writeReg(FXOS8700CQ_M_CTRL_REG2, 0x40);          // Reset all registers to POR values

  _delay_ms(1);        // ~1ms delay

  
  // Initialisierung nach Datenblatt Seite 26ff
  // write 0001 1111 = 0x1F to magnetometer control register 1
  // [7]: m_acal=0: auto calibration disabled
  // [6]: m_rst=0: no one-shot magnetic reset
  // [5]: m_ost=0: no one-shot magnetic measurement
  // [4-2]: m_os=111=7: 8x oversampling (for 200Hz) to reduce magnetometer noise;
  // [1-0]: m_hms=11=3: select hybrid mode with accel and magnetometer active
  writeReg(FXOS8700CQ_M_CTRL_REG1, 0b00011111);

  // write 0010 0000 = 0x20 to magnetometer control register 2
  // [7]: reserved
  // [6]: reserved
  // [5]: hyb_autoinc_mode=1 to map the magnetometer registers to follow the accelerometer registers
  // [4]: m_maxmin_dis=0 to retain default min/max latching even though not used
  // [3]: m_maxmin_dis_ths=0
  // [2]: m_maxmin_rst=0
  // [1-0]: m_rst_cnt=00 to enable magnetic reset each cycle
  //                               76543210
  writeReg(FXOS8700CQ_M_CTRL_REG2, 0b00100000);

  // write 0000 0001= 0x01 to XYZ_DATA_CFG register
  // [7]: reserved
  // [6]: reserved
  // [5]: reserved
  // [4]: hpf_out=0
  // [3]: reserved
  // [2]: reserved
  // [1-0]: fs=01 for ±0.488 mg/LSB ±4 g; fs=00 for ±0.244 mg/LSB ±2 g
  writeReg(FXOS8700CQ_XYZ_DATA_CFG, 0b00000001);

  active();
}



/******************************************************************************
  Set Accel Offset
******************************************************************************/
void FXOS8700CQ::SetAccelOffset()
{
  ReadAccelMagnData();
  //calibrate 14bit Data: 2g mode alles /8; 4g mode /4; 8g mode /1
  float X_Accel_offset = accelData.x / 4 * (-1);         // Compute X-axis offset correction value
  float Y_Accel_offset = accelData.y / 4 * (-1);         // Compute Y-axis offset correction value
  float Z_Accel_offset = (accelData.z - 2048) / 4 * (-1);          // Compute Z-axis offset correction value (SENSITIVITY_2G 4096, SENSITIVITY_4G 2048, SENSITIVITY_8G 1024)

  int8_t xoff = X_Accel_offset;
  int8_t yoff = Y_Accel_offset;
  int8_t zoff = Z_Accel_offset;

  standby();
  writeReg(FXOS8700CQ_OFF_X, xoff);
  writeReg(FXOS8700CQ_OFF_Y, yoff);
  writeReg(FXOS8700CQ_OFF_Z, zoff);
  active();

}


/******************************************************************************
  Write Calibration Magnetic
******************************************************************************/
void FXOS8700CQ::WriteCalibrateMagn()
{

  int16_t Xout_Mag_16_bit_avg2, Yout_Mag_16_bit_avg2, Zout_Mag_16_bit_avg2;

  Xout_Mag_16_bit_avg2 = Xout_Mag_16_bit_avg;
  Yout_Mag_16_bit_avg2 = Yout_Mag_16_bit_avg;
  Zout_Mag_16_bit_avg2 = Zout_Mag_16_bit_avg;

  // Left-shift by one as magnetometer offset registers are 15-bit only, left justified
  Xout_Mag_16_bit_avg2 <<= 1;
  Yout_Mag_16_bit_avg2 <<= 1;
  Zout_Mag_16_bit_avg2 <<= 1;



  standby();

  writeReg(FXOS8700CQ_M_OFF_X_MSB, (Xout_Mag_16_bit_avg2 >> 8) & 0xFF);
  writeReg(FXOS8700CQ_M_OFF_X_LSB, (Xout_Mag_16_bit_avg2 & 0xFF));

  writeReg(FXOS8700CQ_M_OFF_Y_MSB, (Yout_Mag_16_bit_avg2 >> 8) & 0xFF);
  writeReg(FXOS8700CQ_M_OFF_Y_LSB, (Yout_Mag_16_bit_avg2 & 0xFF));

  writeReg(FXOS8700CQ_M_OFF_Z_MSB, (Zout_Mag_16_bit_avg2 >> 8) & 0xFF);
  writeReg(FXOS8700CQ_M_OFF_Z_LSB, (Zout_Mag_16_bit_avg2 & 0xFF));

  active();




}


/******************************************************************************
  Calibrate Magnetic
******************************************************************************/
void FXOS8700CQ::CalibrateMagn()
{

  uint16_t i = 0;


  while (i < 500) {            // 120 * 0.01s = 10s
    ReadAccelMagnData();

    // Assign first sample to maximum and minimum values

    if (i == 0) {

      Xout_Mag_16_bit_max = magData.x;
      Xout_Mag_16_bit_min = magData.x;

      Yout_Mag_16_bit_max = magData.y;
      Yout_Mag_16_bit_min = magData.y;

      Zout_Mag_16_bit_max = magData.z;
      Zout_Mag_16_bit_min = magData.z;
       
    }


    // Check to see if current sample is the maximum or minimum X - axis value

    if (magData.x > Xout_Mag_16_bit_max)    {
      Xout_Mag_16_bit_max = magData.x;
    }
    if (magData.x < Xout_Mag_16_bit_min)    {
      Xout_Mag_16_bit_min = magData.x;
    }


    // Check to see if current sample is the maximum or minimum Y-axis value
    if (magData.y > Yout_Mag_16_bit_max)    {
      Yout_Mag_16_bit_max = magData.y;
    }
    if (magData.y < Yout_Mag_16_bit_min)    {
      Yout_Mag_16_bit_min = magData.y;
    }

    // Check to see if current sample is the maximum or minimum Z-axis value
    if (magData.z > Zout_Mag_16_bit_max)    {
      Zout_Mag_16_bit_max = magData.z;
    }
    if (magData.z < Zout_Mag_16_bit_min)    {
      Zout_Mag_16_bit_min = magData.z;
    }
    i++;
    _delay_ms(10);
  }

  Xout_Mag_16_bit_avg = (Xout_Mag_16_bit_max + Xout_Mag_16_bit_min) / 2;            // X-axis hard-iron offset
  Yout_Mag_16_bit_avg = (Yout_Mag_16_bit_max + Yout_Mag_16_bit_min) / 2;            // Y-axis hard-iron offset
  Zout_Mag_16_bit_avg = (Zout_Mag_16_bit_max + Zout_Mag_16_bit_min) / 2;            // Z-axis hard-iron offset


  WriteCalibrateMagn();


}
